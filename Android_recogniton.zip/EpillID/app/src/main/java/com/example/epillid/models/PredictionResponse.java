package com.example.epillid.models;

public class PredictionResponse {
    public String status;
    public String message;
    public PillInfo pill_info;
    public DisplayData display_quick; // Dữ liệu tóm tắt hiện ở màn hình chính
    public DisplayData display_full;  // Dữ liệu đầy đủ hiện khi bấm nút
}