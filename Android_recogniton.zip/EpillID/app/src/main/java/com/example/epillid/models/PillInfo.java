package com.example.epillid.models;

public class PillInfo {
    public String pill_id;
    public String brand_name;
}