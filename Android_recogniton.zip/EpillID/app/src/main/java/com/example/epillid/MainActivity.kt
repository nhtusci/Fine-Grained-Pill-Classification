package com.example.epillid

import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.epillid.models.DisplayData
import com.example.epillid.models.PredictionResponse
import com.google.gson.Gson
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.asRequestBody
import java.util.concurrent.TimeUnit
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

class MainActivity : AppCompatActivity() {
    private lateinit var imgPreview: ImageView
    private lateinit var tvDrugName: TextView
    private lateinit var tvSummaryUsage: TextView
    private lateinit var tvSummaryDosage: TextView
    private lateinit var tvSummaryWarnings: TextView
    private lateinit var btnFullInfo: Button

    private lateinit var progressBar: ProgressBar

    private var selectedImageUri: Uri? = null

    // IP của Server (Giữ nguyên theo máy của bạn)
    private val API_URL = "http://192.168.1.2:8000/predict"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        imgPreview = findViewById(R.id.imgPreview)
        tvDrugName = findViewById(R.id.tvDrugName)
        tvSummaryUsage = findViewById(R.id.tvSummaryUsage)
        tvSummaryDosage = findViewById(R.id.tvSummaryDosage)
        tvSummaryWarnings = findViewById(R.id.tvSummaryWarnings)
        btnFullInfo = findViewById(R.id.btnFullInfo)
        progressBar = findViewById(R.id.progressBar)

        val btnPick = findViewById<Button>(R.id.btnPick)
        val btnPredict = findViewById<Button>(R.id.btnPredict)

        val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            uri?.let {
                selectedImageUri = it
                imgPreview.setImageURI(it)
                resetUI("Input ready. Click to start identification!")
            }
        }

        btnPick.setOnClickListener { pickImage.launch("image/*") }

        btnPredict.setOnClickListener {
            selectedImageUri?.let { uri ->
                uploadImage(uri)
            } ?: Toast.makeText(this, "Please choose image!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun resetUI(status: String) {
        tvDrugName.text = status
        tvDrugName.setTextColor(Color.BLACK)
        tvSummaryUsage.text = ""
        tvSummaryDosage.text = ""
        tvSummaryWarnings.text = ""
        btnFullInfo.visibility = View.GONE
    }

    private fun uploadImage(uri: Uri) {
        progressBar.visibility = View.VISIBLE
        tvDrugName.text = "Analyzing Image..."
        tvDrugName.setTextColor(Color.GRAY)

        val file = File(cacheDir, "temp_pill_image.jpg")
        contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(file).use { output -> input.copyTo(output) }
        }

        val requestBody = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("file", file.name, file.asRequestBody("image/jpeg".toMediaTypeOrNull()))
            .build()

        val request = Request.Builder()
            .url(API_URL)
            .post(requestBody)
            .build()

        val client = OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS) // Thời gian kết nối tối đa
            .writeTimeout(30, TimeUnit.SECONDS)   // Thời gian gửi dữ liệu tối đa
            .readTimeout(30, TimeUnit.SECONDS)    // Thời gian chờ phản hồi tối đa
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    progressBar.visibility = View.GONE
                    tvDrugName.text = "Connection Timeout"
                    tvDrugName.setTextColor(Color.RED)
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val responseData = response.body?.string()
                runOnUiThread {
                    progressBar.visibility = View.GONE
                    if (response.isSuccessful && responseData != null) {
                        try {
                            val result = Gson().fromJson(responseData, PredictionResponse::class.java)
                            displayResult(result)
                        } catch (e: Exception) {
                            tvDrugName.text = "Data error"
                        }
                    } else {
                        tvDrugName.text = "Server error: ${response.code}"
                    }
                }
            }
        })
    }

    private fun displayResult(result: PredictionResponse) {


        when (result.status) {
            "success" -> {
                // Trường hợp nhận diện thành công
                tvDrugName.text = result.pill_info?.brand_name ?: "Unknown Drug"
                tvDrugName.setTextColor(Color.parseColor("#2E7D32")) // Màu xanh lá đậm

                tvSummaryUsage.text = result.display_quick?.usage
                tvSummaryDosage.text = result.display_quick?.dosage
                tvSummaryWarnings.text = result.display_quick?.warnings

                btnFullInfo.visibility = View.VISIBLE
                btnFullInfo.setOnClickListener {
                    if (result.display_full != null) {
                        showFullInfoPopup(result.display_full, result.pill_info?.brand_name)
                    }
                }
            }

            "low_confidence" -> {
            // Trường hợp ảnh mờ hoặc AI không chắc chắn
                tvDrugName.text = "⚠️ Unclear Image"
                tvDrugName.setTextColor(Color.parseColor("#F57C00")) // Màu cam

                tvSummaryUsage.text = result.message
                tvSummaryDosage.text = "Tips: Keep the camera steady and use good lighting."
                tvSummaryWarnings.text = "Please try again with a clearer photo."
                btnFullInfo.visibility = View.GONE
            }

            "not_pill" -> {
                // Trường hợp ảnh phong cảnh, khuôn mặt, hoặc NIH không tìm thấy mã thuốc
                tvDrugName.text = "🚫 Not a Pill"
                tvDrugName.setTextColor(Color.RED)

                tvSummaryUsage.text = result.display_quick?.usage ?: "Object not identified as a medicine."
                tvSummaryDosage.text = "Note: The system only recognizes FDA-approved pills."
                tvSummaryWarnings.text = "Avoid taking photos of landscapes or non-medical objects."
                btnFullInfo.visibility = View.GONE
            }

            "error" -> {
                tvDrugName.text = "❌ System Error"
                tvDrugName.setTextColor(Color.RED)
                Toast.makeText(this, result.message, Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun showFullInfoPopup(fullData: DisplayData, brandName: String?) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Full Information: ${brandName ?: "Pill"}")

        val scrollView = ScrollView(this)
        val tvFull = TextView(this)
        tvFull.setPadding(40, 40, 40, 40)
        tvFull.textSize = 15f
        tvFull.setTextColor(Color.BLACK)

        val content = "【INDICATIONS & USAGE】\n${fullData.usage}\n\n" +
                "【DOSAGE & ADMINISTRATION】\n${fullData.dosage}\n\n" +
                "【WARNINGS】\n${fullData.warnings}"

        tvFull.text = content
        scrollView.addView(tvFull)

        builder.setView(scrollView)
        builder.setPositiveButton("Close", null)
        builder.show()
    }
}