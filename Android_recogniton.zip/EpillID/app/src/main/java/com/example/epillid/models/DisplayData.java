package com.example.epillid.models;

public class DisplayData {
    public String usage;
    public String dosage;
    public String warnings;
}